<?php
session_start();

/**
 * Check if the user is authenticated
 *
 * @return bool True if the user is authenticated, otherwise false
 */
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

/**
 * Get the role of the currently logged-in user
 *
 * @return string|null The role of the user, or null if not logged in
 */
function getRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Authorize a user to access a page based on their role
 *
 * @param array $allowed_roles The roles that are allowed to access the page
 */
function authorize($allowed_roles) {
    if (!isAuthenticated() || !in_array(getRole(), $allowed_roles)) {
        // Redirect to a 404 or unauthorized access page
        header("Location: 404.php");
        exit();
    }
}

/**
 * Redirect authenticated users based on their role
 */
function redirectToRoleDashboard() {
    if (isAuthenticated()) {
        switch (getRole()) {
            case 'admin':
                header("Location: admin_dashboard.php");
                break;
            case 'sales':
                header("Location: orders.php");
                break;
            case 'inventory':
                header("Location: products.php");
                break;
            case 'customer':
                header("Location: customer_dashboard.php");
                break;
            default:
                header("Location: login.php");
                break;
        }
        exit();
    }
}
?>
