<?php
include 'auth.php';
authorize(['admin']); // Only admins can access this page
include 'connection.php'; // Database connection

// Fetch users
$users = $conn->query("SELECT * FROM users");

// Fetch products
$products = $conn->query("SELECT * FROM products");

// Fetch orders
$orders = $conn->query("SELECT * FROM orders");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome, Admin</h1>
    <h2>Users</h2>
    <table>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>
        <?php while ($user = $users->fetch_assoc()): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= $user['name'] ?></td>
                <td><?= $user['email'] ?></td>
                <td><?= $user['role'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h2>Products</h2>
    <table>
        <tr><th>ID</th><th>Name</th><th>Price</th><th>Stock</th></tr>
        <?php while ($product = $products->fetch_assoc()): ?>
            <tr>
                <td><?= $product['id'] ?></td>
                <td><?= $product['name'] ?></td>
                <td><?= $product['price'] ?></td>
                <td><?= $product['stock_quantity'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h2>Orders</h2>
    <table>
        <tr><th>ID</th><th>User ID</th><th>Total</th><th>Date</th></tr>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <tr>
                <td><?= $order['id'] ?></td>
                <td><?= $order['user_id'] ?></td>
                <td><?= $order['total_amount'] ?></td>
                <td><?= $order['date'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
